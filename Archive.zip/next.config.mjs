/** @type {import('next').NextConfig} */
const nextConfig = {
    // async redirects() {
    //     return [
    //         {
    //             source: "/blabla",
    //             destination: "/login",
    //             permanent: true
    //         }
    //     ]
    // },
    // i18n: {
    //     locales: ['en', 'fr', 'es', 'ru'], // List of supported locales
    //     defaultLocale: 'ru', // Default locale is set to English
    //   },
};

export default nextConfig;
