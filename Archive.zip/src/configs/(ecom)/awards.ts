const awardsDetails = [
    {
        src: "/img/awwwards.png",
        title: "WEBSITE OF THE DAY",
        number: "4",
    },
    {
        src: "/img/cssdesignawards.png",
        title: "UI Design Award",
        number: "6",
    }, {
        src: "/img/awwwards.png",
        title: "STAR AWARD",
        number: "7",
    },
]


export const getAwardsData = () => awardsDetails;