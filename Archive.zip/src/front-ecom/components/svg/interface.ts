export interface IIconProps {
    size: string;
    // width: string;
    // height: string;
    color: string;
}