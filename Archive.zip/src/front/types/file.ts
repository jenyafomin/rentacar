export type FileProp = {
    file?: File;
    url: string;
};